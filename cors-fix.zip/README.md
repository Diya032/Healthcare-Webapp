# Healthcare-Webapp
Monolithic repo structure instead of microservice 
