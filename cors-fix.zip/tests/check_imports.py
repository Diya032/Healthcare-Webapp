import fastapi
print("FastAPI version:", fastapi.__version__)
